/*============================================================================
	Name        : GameBoard.Java (Class)
	Author      : Titus Varghese
	Course	    : 2336
	Section     : 006
	Analysis    : This class will set up the individual game boards which make up the Ultimate Tic-Tac-Toe Game.
	Design      : GameBoard class was used to construct the individual boards that make up the ultimate tttgame
				  and this class was used to set up basic board labels and status checks for the empty positions.
	Test	    : This class was tested using breakpoints, which ensured the proper values 
				  were being passed through at the appropriate times.
  ============================================================================*/
// finalProject package
package finalProject;
//creates public class called GameBoard
public class GameBoard {
	// creates private variable of final integer type called boardRowCount and sets it to a value of three 
	private final int boardRowCount = 3;
	// creates private variable of final integer type called boardColumnCount and sets it to a value of three 
	private final int boardColumnCount = 3;
	// creates private variable of integer type called rowInMasterBoard
	private int rowInMasterBoard;
	// creates private variable of integer type called columnInMasterBoard
	private int columnInMasterBoard;
	// creates private variable of IndividualBoardStatus type called boardStatus
	private IndividualBoardStatus boardStatus;
	// creates private variable of GameboardCell [][]  type called gameBoard
	private GameboardCell [][] gameBoard;
	// creates private variable of String type called boardPositionLabel
	private String boardPositionLabel;
	// creates GameBoard constructor
	public GameBoard(int masterBoardRow, int masterBoardColumn) {
		// sets gameBoard variable to new instance of GameboardCell method
		gameBoard = new GameboardCell [boardRowCount][boardColumnCount];
		// goes through the board
		for(int r = 0; r < boardRowCount; r ++) {
			for(int c = 0; c < boardColumnCount; c++) {
				gameBoard[r][c] = new GameboardCell(r,c);
			}
		}
		this.rowInMasterBoard = masterBoardRow; // sets rowInMasterBoard to value of masterBoardRow
		this.columnInMasterBoard = masterBoardColumn; // sets columnInMasterBoard to value of masterBoardColumn
		// sets board status to active
		this.boardStatus = IndividualBoardStatus.ACTIVE;
		setBoardLabel(); // calls setBoardLabel method
	}
	// creates public method of void type called setBoardLabel
	// to set the value of the boardPositionLabel
	public void setBoardLabel() {
		// sets boardPositionLabel to upper-left quadrant
		if(rowInMasterBoard == 0 && columnInMasterBoard == 0) {
			this.boardPositionLabel = "upper-left";
		}
		// sets boardPositionLabel to upper-middle quadrant
		if(rowInMasterBoard == 0 && columnInMasterBoard == 1) {
			this.boardPositionLabel = "upper-middle";
		}
		// sets boardPositionLabel to upper-right quadrant
		if(rowInMasterBoard == 0 && columnInMasterBoard == 2) {
			this.boardPositionLabel = "upper-right";
		}
		// sets boardPositionLabel to middle-left quadrant
		if(rowInMasterBoard == 1 && columnInMasterBoard == 0) {
			this.boardPositionLabel = "middle-left";
		}
		// sets boardPositionLabel to center quadrant
		if(rowInMasterBoard == 1 && columnInMasterBoard == 1) {
			this.boardPositionLabel = "center";
		}
		// sets boardPositionLabel to middle-right quadrant
		if(rowInMasterBoard == 1 && columnInMasterBoard == 2) {
			this.boardPositionLabel = "middle-right";
		}
		// sets boardPositionLabel to lower-left quadrant
		if(rowInMasterBoard == 2 && columnInMasterBoard == 0) {
			this.boardPositionLabel = "lower-left";
		}
		// sets boardPositionLabel to lower-middle quadrant
		if(rowInMasterBoard == 2 && columnInMasterBoard == 1) {
			this.boardPositionLabel = "lower-middle";
		}
		// sets boardPositionLabel to lower-right quadrant
		if(rowInMasterBoard == 2 && columnInMasterBoard == 2) {
			this.boardPositionLabel = "lower-right";
		}
	}
	// creates public method of GameboardCell type called getIndividualCell
	// to set the value of the gameBoard method
	public GameboardCell getIndividualCell(int row, int column) {
		return this.gameBoard[row][column];
	}
	// creates public method of void type called setIndividualCell
	// to set the value of the setCurrentCellValue value
	public void setIndividualCell(int row, int column, CellConstant mark) {
		this.gameBoard[row][column].setCurrentCellValue(mark); // sets mark value to cell
	}
	// creates public method of IndividualBoardStatus type called getIndividualBoardStatus
	// to get the value of the boardStatus variable
	public IndividualBoardStatus getIndividualBoardStatus() {
		return this.boardStatus; // returns value of boardStatus variable
	}
	// creates public method of void type called displayBoard
	// to set up the smaller boards
	public void displayBoard() {
		for(int r = 0; r < boardRowCount; r ++) {
			for(int c = 0; c < boardColumnCount; c++) {
				gameBoard[r][c].printCell();
				if(c < 2) {
					System.out.print("|");
				}
			}
			System.out.println();
			if(r < 2) {
				System.out.println("-------");
			}
		}
	}
	// creates public method of GameboardCell[] type called getBoardRow
	// to get the value of the gameBoard method
	public GameboardCell[] getBoardRow(int row) {
		return this.gameBoard[row]; // returns gameBoard value
	}
	// creates public method of void type called checkBoardStatus
	// to check the winner of the boards
	public void checkBoardStatus(CellConstant currentPlayerMark) {
		for(int r = 0; r < boardRowCount; r++) {
			// checks if player won a specific board
			if(gameBoard[r][0].getCurrentCellValue() == currentPlayerMark &&
					gameBoard[r][1].getCurrentCellValue() == currentPlayerMark &&
							gameBoard[r][2].getCurrentCellValue() == currentPlayerMark
					) {
				this.boardStatus = ((currentPlayerMark == CellConstant.X) ? IndividualBoardStatus.XWIN : IndividualBoardStatus.OWIN);
				System.out.println("Player: " + currentPlayerMark.toString() + " has won the " + this.boardPositionLabel + " board.");
			}
		}
		for(int c = 0; c < boardColumnCount; c++) {
			// checks if player won a specific board
			if(gameBoard[0][c].getCurrentCellValue() == currentPlayerMark &&
					gameBoard[1][c].getCurrentCellValue() == currentPlayerMark &&
							gameBoard[2][c].getCurrentCellValue() == currentPlayerMark
					) {
				this.boardStatus = ((currentPlayerMark == CellConstant.X) ? IndividualBoardStatus.XWIN : IndividualBoardStatus.OWIN);
				System.out.println("Player: " + currentPlayerMark.toString() + " has won the " + this.boardPositionLabel + " board.");
			}
		}
		// checks if player won a specific board
		if(gameBoard[2][0].getCurrentCellValue() == currentPlayerMark &&
				gameBoard[1][1].getCurrentCellValue() == currentPlayerMark &&
						gameBoard[0][2].getCurrentCellValue() == currentPlayerMark) {
			this.boardStatus = ((currentPlayerMark == CellConstant.X) ? IndividualBoardStatus.XWIN : IndividualBoardStatus.OWIN);
			System.out.println("Player: " + currentPlayerMark.toString() + " has won the " + this.boardPositionLabel + " board.");
		}
		// checks if player won a specific board
		if(gameBoard[0][0].getCurrentCellValue() == currentPlayerMark &&
				gameBoard[1][1].getCurrentCellValue() == currentPlayerMark &&
						gameBoard[2][2].getCurrentCellValue() == currentPlayerMark) {
			this.boardStatus = ((currentPlayerMark == CellConstant.X) ? IndividualBoardStatus.XWIN : IndividualBoardStatus.OWIN);
			System.out.println("Player: " + currentPlayerMark.toString() + " has won the " + this.boardPositionLabel + " board.");
		}
	}
	// creates public method of boolean type called checkBoardForBlank
	// to check the values of the  board for blanks
	public boolean checkBoardForBlank() {
		int blankLocatedFlag = -1;
		for(int x = 0; x < 3; x++) {
			for(int y = 0; y < 3; y++) {
				if(this.getIndividualCell(x, y).getCurrentCellValue() == CellConstant.BLANK) {
					blankLocatedFlag = 1; // sets blankLocatedFlag variable to value of one
				}
			}
		}
		// checks if blankLocatedFlag is equal to value of one
		if(blankLocatedFlag == 1) {
			return true; // returns a value of true
		}
		else {
			return false; // returns a value of false
		}
	}
	// creates public method of String type called getBoardPositionLabel
	// to get the boardPositionLabel variable 
	public String getBoardPositionLabel() {
		return boardPositionLabel; // returns the boardPositionLabel value
	}
	// creates public method of void type called setBoardPositionLabel
	// to set the value of the boardPositionLabel
	public void setBoardPositionLabel(String boardPositionLabel) {
		this.boardPositionLabel = boardPositionLabel;
	}	
}