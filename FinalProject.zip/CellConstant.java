/*============================================================================
	Name        : CellConstant.Java (enum)
	Author      : Titus Varghese
	Course	    : 2336
	Section     : 006
	Analysis    : This class will store the enum constants used within the Ultimate Tic-Tac-Toe Game.
	Design      : CellConstant holds the possible enum constants for the positions within the game board.
	Test	    : This class was tested in situations to signify a specific constant.
  ============================================================================*/
// finalProject package
package finalProject;
// creates public method of enumeration type called CellConstant
public enum CellConstant {
	// creates enums called BLANK, X, and O
	BLANK, X, O
}