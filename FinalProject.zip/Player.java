/*======================================================================================
	Name        : Player.Java (Class)
	Author      : Titus Varghese
	Course	    : 2336
	Section     : 006
	Analysis    : This class will set up the Player for the Ultimate Tic-Tac-Toe Game.
	Design      : Player controls the individual player's corresponding input and marks
	 			  in order to move the ultimate ttt game further in the process.
	Test	    : This class was tested using breakpoints, which ensured the proper values 
				  were being passed through at the appropriate times. Invalid input was
				  also tested to ensure only valid input was entered by the Player.
  ======================================================================================*/
// finalProject package
package finalProject;
// imports the java scanner element
import java.util.Scanner;
// creates public Player constructor
public class Player {
	// creates private variable of CellConstant type called playerMark
	private CellConstant playerMark;
	// creates private variable of IndividualBoardStatus type called winningBoardStatus
	private IndividualBoardStatus winningBoardStatus;
	// creates public method of CellConstant type called getPlayerMark
	public CellConstant getPlayerMark() {
		return this.playerMark; // returns the playerMark value
	}
	// creates public method of IndividualBoardStatus type called getWinningBoardStatus
	public IndividualBoardStatus getWinningBoardStatus() {
		return this.winningBoardStatus; // returns the winningBoardStatus value
	}
	// creates public Player constructor
	public Player(String mark) {
		// checks if value of mark is equal to X or O marks
		if(mark == CellConstant.O.toString() || mark == CellConstant.X.toString()){
			// sets playerMark
			this.playerMark = (mark == "X") ? CellConstant.X : CellConstant.O;
			// sets winningBoardStatus
			this.winningBoardStatus = (mark == "X") ? IndividualBoardStatus.XWIN : IndividualBoardStatus.OWIN;
		}
	}
	// creates public method of void type called swap
	public void swap() {
		// checks if playerMark is O
		if(this.playerMark == CellConstant.O){
			this.playerMark = CellConstant.X; // sets playerMark to X
		}
		// checks if playerMark is X
		if(this.playerMark == CellConstant.X){
			this.playerMark = CellConstant.O; // sets playerMark to O
		}
	}
	// creates public method of integer array type called GetPlayerInput
	public int[] GetPlayerInput() {
		// creates scanner element called input
		Scanner input;
		input = new Scanner(System.in);
		// creates integer variable called inputArray[] and creates new instance with size of 2
		int inputArray[] = new int[2];
		// displays statement to the screen for the specific player to select a row number
		System.out.println("Player: " + this.getPlayerMark() + ", Please enter the row number of your move: ");
		// creates variable of integer type called row and sets it to the input scanner element
		int row = input.nextInt();
		// displays statement to the screen for the specific player to select a column number
		System.out.println("Player: " + this.getPlayerMark() + ", Please enter the column number of your move: ");
		int column = input.nextInt();
		--row; // decrements row variable value
		--column; // decrements column variable value
		inputArray[0] = row; // sets value of inputArray[0] to row variable
		inputArray[1] = column; // sets value of inputArray[1] to column variable
		return inputArray; // returns inputArray value
	}
}