/*============================================================================
	Name        : GameboardCell.Java (Class)
	Author      : Titus Varghese
	Course	    : 2336
	Section     : 006
	Analysis    : This class will set up the individual game board cells that make up the 
				  larger Ultimate Tic-Tac-Toe Game board.
	Design      : GameboardCell takes into account the small cells that make up 
				  each small board and was used to get, set, and print various cell values.
	Test	    : This class was tested using breakpoints, which ensured the proper values 
				  were being passed through at the appropriate times.
  ============================================================================*/
// finalProject package
package finalProject;
// creates public class called GameboardCell
public class GameboardCell {
	// creates private variable of integer type called row
	private int row;
	// creates private variable of integer type called column
	private int column;
	// creates private variable of CellConstant type called cellValue
	private CellConstant cellValue;
	// public GameboardCell constructor
	public GameboardCell(int rowSet, int columnSet){
		this.row = rowSet; // sets value of row
		this.column = columnSet; // sets value of column
		this.cellValue = CellConstant.BLANK; // sets value of cellValue
	}
	// creates public method of CellConstant type called getCurrentCellValue
	// to get the value of the cellValue
	public CellConstant getCurrentCellValue() {
		return this.cellValue; // returns cellValue variable
	}
	// creates public method of void type called setCurrentCellValue
	// to set the value of the mark
	public void setCurrentCellValue(CellConstant mark) {
		this.cellValue = mark; 
	}
	// creates public method of void type called printCell
	// to print the values within each cell
	public void printCell() {
		// checks if cell value is blank
		if(cellValue == CellConstant.BLANK) {
			System.out.print('_'); // sets cell mark to _
		}
		// checks if cell value is X
		if(cellValue == CellConstant.X) {
			System.out.print('X'); // sets cell mark to X
		}
		// checks if cell value is O
 		if(cellValue == CellConstant.O) {
 			System.out.print('O'); // sets cell mark to O
		}
	}
}