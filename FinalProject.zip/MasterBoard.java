/*============================================================================
	Name        : MasterBoard.Java (Class)
	Author      : Titus Varghese
	Course	    : 2336
	Section     : 006
	Analysis    : This class will set up the master board for the Ultimate Tic-Tac-Toe Game.
	Design      : MasterBoard is used to structure the individual GameBoard classes within the
				  larger ultimate ttt game and it also set up basic methods used for the display.
	Test	    : This class was tested using breakpoints, which ensured the proper values 
				  were being passed to the board at the appropriate times.
  ============================================================================*/
// finalProject package
package finalProject;
// creates public class called MasterBoard
public class MasterBoard {
	// creates private variable of final integer type called masterBoardRowCount and sets it to a value of three 
	private final int masterBoardRowCount = 3;
	// creates private variable of final integer type called masterBoardColumnCount and sets it to a value of three 
	private final int masterBoardColumnCount = 3;
	// creates private variable of GameBoard[][] type called masterGameBoard 
	private GameBoard [][] masterGameBoard;
	// creates private variable of MasterGameStatus type called statusOfMasterGame
	private MasterGameStatus statusOfMasterGame;
	// creates public constructor for MasterBoard
	public MasterBoard() {
		// sets masterGameBoard to new instance of GameBoard
		masterGameBoard = new GameBoard [masterBoardRowCount][masterBoardColumnCount];
		// goes through the ultimate board
		for(int r = 0; r < masterBoardRowCount; r ++) {
			for(int c = 0; c < masterBoardColumnCount; c++) {
				masterGameBoard[r][c] = new GameBoard(r,c);
			}
		}
	}
	// creates public method of GameBoard type called getIndividualBoard
	// to get the value of the individual boards
	public GameBoard getIndividualBoard(int row, int column) {
		return masterGameBoard[row][column]; // returns masterGameBoard method value
	}
	// creates public method of MasterGameStatus type called getStatusOfMasterGame
	// to get the statusOfMasterGame variable 
	public MasterGameStatus getStatusOfMasterGame() {
		return this.statusOfMasterGame; // returns statusOfMasterGame variable value
	}
	// creates public method of void type called setStatusOfMasterGame
	// to set the value of the statusToSet variable
	public void setStatusOfMasterGame(MasterGameStatus statusToSet) {
		this.statusOfMasterGame = statusToSet; //sets the value of statusToSet
	}
	// creates public method of integer array type called displayMasterBoard
	// to display the ultimate tic-tac-toe game board out to the screen
	public void displayMasterBoard() {
		// prints out the statement informing the players that the current board is being displayed
		System.out.println("CURRENT BOARD: ");
		// prints out the display for the ultimate ttt game labels
		System.out.print("    1   2   3        4   5   6        7   8   9  ");
		System.out.println();
		// prints out the display for the ultimate ttt game
		for (int x = 0; x < 9; x++) {
			System.out.print(x + 1);			
			GameboardCell[] CellRow = getMasterBoardRow(x);
			for (int i = 0; i < 9; i++) {
				System.out.print(" | ");
				if (CellRow[i] != null) {
					CellRow[i].printCell();
				}
				if((i+1) % 3 == 0 && i != 8) {
					System.out.print(" | ");
					System.out.print("  ");
				}
			}
			System.out.print(" | ");
			System.out.println();
			if((x+1) % 3 == 0) {
				System.out.println();
			}
		}
	}
	// creates public method of GameboardCell type called getIndividualGameBoardCell
	// to get the value of the individual game board cells
	public GameboardCell getIndividualGameBoardCell(int boardArrayRow, int boardArrayColumn, int individualRow, int individualColumn) {
		// creates a variable of GameBoard called tempBoardRow
		GameBoard tempBoardRow = this.masterGameBoard[boardArrayRow][boardArrayColumn];
		// creates a variable of GameBoard called tempCell
		GameboardCell tempCell = tempBoardRow.getIndividualCell(individualRow, individualColumn);
		return tempCell; // returns tempCell variable value
	}
	// creates public method of GameboardCell[] type called getMasterBoardRow
	// to get the value of the rows from the Master board
	public GameboardCell[] getMasterBoardRow(int masterBoardRow) {
		// creates variable of GameboardCell[] type called cellList and sets it to array size of 9
		GameboardCell[] cellList = new GameboardCell[9];
		// creates variable of integer array type called boardRowArray and sets it to array size of 2
		int[] boardRowArray = new int[2];
		// sets boardRowArray value to getBoardRows method
		boardRowArray = getBoardRows(masterBoardRow);
		// goes through the board to count all the cells
		for(int cellListCount = 0; cellListCount < 9; cellListCount++) {
				int individualBoardColumn = (cellListCount % 3);
				cellList[cellListCount] = this.getIndividualGameBoardCell(boardRowArray[0], getMasterBoardColumn(cellListCount), boardRowArray[1], individualBoardColumn);
		}
		return cellList; // returns cellList variable value
	}
	// creates public method of integer array type called getMasterBoardColumn
	// to get the values of the master board columns
	public int getMasterBoardColumn(int masterBoardColumn) {
		int individualBoardColumn = -1; 
		// creates switch statement to set values of master board columns
		switch(masterBoardColumn) {
		case(0): 
			individualBoardColumn = 0;
		break;
		case(1):
			individualBoardColumn = 0;
		break;
		case(2):
			individualBoardColumn = 0;
		break;
		case(3):
			individualBoardColumn = 1;
		break;
		case(4):
			individualBoardColumn = 1;
		break;
		case(5):
			individualBoardColumn = 1;
		break;
		case(6):
			individualBoardColumn = 2;
		break;
		case(7):
			individualBoardColumn = 2;
		break;
		case(8):
			individualBoardColumn = 2;
		break;
		}
		return individualBoardColumn; // returns individualBoardColumn variable value
		}	
	// creates public method of integer array type called getBoardRows
	// to get the board rows from the Master board integer variable
	public int[] getBoardRows(int masterBoardRow){
		// creates integer variable called masterAndIndividualBoardRow[] and sets it to array size of 2
		int masterAndIndividualBoardRow[] = new int[2];
		// creates switch statement to set values of masterBoardRow
		switch(masterBoardRow) {
		case(0): 
			masterAndIndividualBoardRow[0] = 0;
			masterAndIndividualBoardRow[1] = 0;
		break;
		case(1):
			masterAndIndividualBoardRow[0] = 0;
			masterAndIndividualBoardRow[1] = 1;
		break;
		case(2):
			masterAndIndividualBoardRow[0] = 0;
			masterAndIndividualBoardRow[1] = 2;
		break;
		case(3):
			masterAndIndividualBoardRow[0] = 1;
		masterAndIndividualBoardRow[1] = 0;
		break;
		case(4):
			masterAndIndividualBoardRow[0] = 1;
		masterAndIndividualBoardRow[1] = 1;
		break;
		case(5):
			masterAndIndividualBoardRow[0] = 1;
			masterAndIndividualBoardRow[1] = 2;
		break;
		case(6):
			masterAndIndividualBoardRow[0] = 2;
			masterAndIndividualBoardRow[1] = 0;
		break;
		case(7):
			masterAndIndividualBoardRow[0] = 2;
			masterAndIndividualBoardRow[1] = 1;
		break;
		case(8):
			masterAndIndividualBoardRow[0] = 2;
			masterAndIndividualBoardRow[1] = 2;
		break;
		}
		return masterAndIndividualBoardRow; // returns masterAndIndividualBoardRow variable value
	}
	// creates public method of integer type called calculateMasterBoardRow
	// to set the value of the master board row values
	public int calculateMasterBoardRow(int masterBoardRow){
		int masterBoardRowValue = -1;
		// creates switch statement to set values of masterBoardRow
		switch(masterBoardRow) {
		case(0): 
			masterBoardRowValue = 0;
		break;
		case(1):
			masterBoardRowValue = 0;
		break;
		case(2):
			masterBoardRowValue = 0;
		break;
		case(3):
			masterBoardRowValue = 1;
		break;
		case(4):
			masterBoardRowValue = 1;
		break;
		case(5):
			masterBoardRowValue = 1;
		break;
		case(6):
			masterBoardRowValue = 2;
		break;
		case(7):
			masterBoardRowValue = 2;
		break;
		case(8):
			masterBoardRowValue = 2;
		break;
		}
		return masterBoardRowValue; // returns masterBoardRowValue variable value
	}
	// creates public method of void type called validateMasterGameStatus
	// to check master game status
	public void validateMasterGameStatus(Player currentPlayer) {
		// checks for situation of a win
		for(int r = 0; r < masterBoardRowCount; r++) {
			if(masterGameBoard[r][0].getIndividualBoardStatus() == currentPlayer.getWinningBoardStatus() &&
					masterGameBoard[r][1].getIndividualBoardStatus() == currentPlayer.getWinningBoardStatus() &&
							masterGameBoard[r][2].getIndividualBoardStatus() == currentPlayer.getWinningBoardStatus()
					) {
				this.statusOfMasterGame = (currentPlayer.getPlayerMark() == CellConstant.X) ? MasterGameStatus.XWIN : MasterGameStatus.OWIN;
				this.displayMasterBoard();
				// displays statement to the screen indicating a player has won the game
				System.out.println("Player " + currentPlayer.getPlayerMark() + " has won the game!");
				System.out.println("========================= THANK YOU FOR PLAYING THE ULTIMATE TIC-TAC-TOE GAME! =========================");
				return; // returns label variable value
			}
		}
		// checks for situation of a win
		for(int c = 0; c < masterBoardColumnCount; c++) {
			if(masterGameBoard[0][c].getIndividualBoardStatus() == currentPlayer.getWinningBoardStatus() &&
					masterGameBoard[1][c].getIndividualBoardStatus() == currentPlayer.getWinningBoardStatus() &&
							masterGameBoard[2][c].getIndividualBoardStatus() == currentPlayer.getWinningBoardStatus()
					) {
				this.statusOfMasterGame = (currentPlayer.getPlayerMark() == CellConstant.X) ? MasterGameStatus.XWIN : MasterGameStatus.OWIN;
				this.displayMasterBoard();
				// displays statement to the screen indicating a player has won the game
				System.out.println("Player " + currentPlayer.getPlayerMark() + " has won the game!");
				System.out.println("========================= THANK YOU FOR PLAYING THE ULTIMATE TIC-TAC-TOE GAME! =========================");
				return; // returns label variable value
			}
		}
		// checks for situation of a win
		if(masterGameBoard[2][0].getIndividualBoardStatus() == currentPlayer.getWinningBoardStatus() &&
				masterGameBoard[1][1].getIndividualBoardStatus() == currentPlayer.getWinningBoardStatus() &&
						masterGameBoard[0][2].getIndividualBoardStatus() == currentPlayer.getWinningBoardStatus()) {
			this.statusOfMasterGame = (currentPlayer.getPlayerMark() == CellConstant.X) ? MasterGameStatus.XWIN : MasterGameStatus.OWIN;
			this.displayMasterBoard();
			// displays statement to the screen indicating a player has won the game
			System.out.println("Player " + currentPlayer.getPlayerMark() + " has won the game!");
			System.out.println("========================= THANK YOU FOR PLAYING THE ULTIMATE TIC-TAC-TOE GAME! =========================");
			return; // returns label variable value
		}
		// checks for situation of a win
		if(masterGameBoard[0][0].getIndividualBoardStatus() == currentPlayer.getWinningBoardStatus() &&
				masterGameBoard[1][1].getIndividualBoardStatus() == currentPlayer.getWinningBoardStatus() &&
						masterGameBoard[2][2].getIndividualBoardStatus() == currentPlayer.getWinningBoardStatus()) {
			this.statusOfMasterGame = (currentPlayer.getPlayerMark() == CellConstant.X) ? MasterGameStatus.XWIN : MasterGameStatus.OWIN;
			this.displayMasterBoard();
			// displays statement to the screen indicating a player has won the game
			System.out.println("Player " + currentPlayer.getPlayerMark() + " has won the game!");
			System.out.println("========================= THANK YOU FOR PLAYING THE ULTIMATE TIC-TAC-TOE GAME! =========================");
			return; // returns label variable value
		}
		// checks for situation of a tie
		if(checkMasterBoardForBlank() == false) {
			this.statusOfMasterGame = MasterGameStatus.TIE;
			this.displayMasterBoard();
			// displays statement to the screen indicating a tie has occurred
			System.out.println("Game has ended with a tie! GG!");
			System.out.println("========================= THANK YOU FOR PLAYING THE ULTIMATE TIC-TAC-TOE GAME! =========================");
			return; // returns label variable value
		}
	}
	// creates public method of boolean type called checkMasterBoardForBlank
	// to check the values of the master board for blanks
	public boolean checkMasterBoardForBlank() {
		// creates variable of boolean type called blankFound and sets it to a value of false
		boolean blankFound = false;
		// iterates through to find the blank spaces within the board
		for(int row = 0; row < 3 && (blankFound == false); row++) {
			for(int column = 0; column < 3 && (blankFound == false); column++) {
				blankFound = this.masterGameBoard[row][column].checkBoardForBlank();
			}
		}
		return blankFound; // returns blankFound variable value
	}
	// creates public method of integer array type called getBoardFromMasterWithBlank
	// to get the value of the boards from the Master board
	public int[] getBoardFromMasterWithBlank() {
		// creates a variable of integer array type called masterBoardCoordinates and sets it to size of 2
		int[] masterBoardCoordinates = new int[2];
		// creates variable of boolean type called blankOnBoard and sets it to a value of false
		boolean blankOnBoard = false;
		// iterates through to find the blank spaces within the board
		for(int row = 0; row < 3 && (blankOnBoard == false); row++) {
			for(int column = 0; column < 3 && (blankOnBoard == false); column++) {
				blankOnBoard = this.masterGameBoard[row][column].checkBoardForBlank();
				masterBoardCoordinates[0] = row;
				masterBoardCoordinates[1] = column;		
			}
		}
		return masterBoardCoordinates; // returns masterBoardCoordinates variable value
	}
}