/*======================================================================================
	Name        : GameRunner.Java (Class)
	Author      : Titus Varghese
	Course	    : 2336
	Section     : 006
	Analysis    : This class will serve as the main driver for the Ultimate Tic-Tac-Toe Game.
	Design      : GamerRunner controls the overall flow of the program and maintains 
				  the state of all the sub-boards and sub-games within the ultimate game .
	Test	    : This class was tested using breakpoints, which ensured the proper values 
				  were being passed through the program at the appropriate times.
  ======================================================================================*/
// finalProject package
package finalProject;
// imports java Scanner element
import java.util.Scanner;
//imports java Random 
import java.util.Random;
// creates a public constructor of GameRunner
public class GameRunner {
	// creates private static variable of Scanner type called userEntry and creates new instance called Scanner in
	private static Scanner userEntry = new Scanner(System.in);
	// creates private variable of Player type called humanPlayer
	private Player humanPlayer;
	// creates private variable of Player type called humanPlayer
	private Player aiPlayer;
	// creates private variable of MasterBoard type called ultimateTTTBoard
	private MasterBoard ultimateTTTBoard;
	// creates private variable of MasterGameStatus type called gameStatus
	private MasterGameStatus gameStatus;
	// creates private variable of PreviousMove type called lastMove
	private PreviousMove lastMove;
	// creates private variable of integer array type called validQuadrantForNextMove
	private int[] validQuadrantForNextMove;
	// creates public method of static void type called main
	public static void main(String args[]){
		new GameRunner(); // calls new instance of GameRunner
	}
	// creates public constructor of GameRunner
	public GameRunner() {
		// creates variable called ultimateTTTBoard and sets it to a new instance of the MasterBoard method
		ultimateTTTBoard = new MasterBoard();
		// creates variable called humanPlayer and sets it to new instance of Player "X" 
		humanPlayer = new Player("X");
		// creates variable called aiPlayer and sets it to new instance of Player "O" 
		aiPlayer = new Player("O");
		// creates variable of Player type called currentPlayer and sets it to humanPlayer
		Player currentPlayer = humanPlayer;
		// sets status to active
		ultimateTTTBoard.setStatusOfMasterGame(MasterGameStatus.ACTIVE); 
		// sets lastMove to new instance of previousMove method
		this.lastMove = new PreviousMove();
		// calls printRules method
		this.printRules();
		do {
			// checks if player is humanPlayer
			if(currentPlayer.getPlayerMark() == CellConstant.X) {
				// displays current board to the display
				ultimateTTTBoard.displayMasterBoard();
				// begins Human Player's turn
				this.takeHumanTurn(currentPlayer);
			}
			// checks if player is aiPlayer
			if(currentPlayer.getPlayerMark() == CellConstant.O) {
				// begins Ai's turn
				this.takeAiTurn(currentPlayer);
			}
			// updates Board Status
			this.updateStatusForBoards();
			// validates Master Game Status
			ultimateTTTBoard.validateMasterGameStatus(currentPlayer);
			if(currentPlayer == humanPlayer) {
				currentPlayer = aiPlayer;
			}
			// current player defaults to humanPlayer
			else {
				currentPlayer = humanPlayer;
			}
		}
		// checks while game status is active
		while(ultimateTTTBoard.getStatusOfMasterGame() == MasterGameStatus.ACTIVE);
	}
	// creates public method called takeHumanTurn of void type 
	// to control the human's turn in the game
	public void takeHumanTurn(Player currentPlayer) {
		// creates boolean variable called isBlankOnValidQuadrant and sets it to false
		boolean isBlankOnValidQuadrant = false;
		// creates boolean variable called isBlankOnMasterBoard and sets it to checkMasterBoardForBlank
		boolean isBlankOnMasterBoard = ultimateTTTBoard.checkMasterBoardForBlank();
		// checks if not equal to isBlankOnMasterBoard value
		if(!isBlankOnMasterBoard) {
			ultimateTTTBoard.validateMasterGameStatus(currentPlayer); // validates Game Status
		}
		// checks if last coordinates are not equal to null
		if(this.lastMove.getLastCoordinates() != null) {
			int[] validQuadrantForNextMove = this.lastMove.getLastCoordinates();
			isBlankOnValidQuadrant = ultimateTTTBoard.getIndividualBoard(validQuadrantForNextMove[0], validQuadrantForNextMove[1]).checkBoardForBlank();
			this.validQuadrantForNextMove = determineValidQuadrant();
			// if blank is valid position
			if(isBlankOnValidQuadrant) {
				// Displays message to the screen for where the Player can make their next move
				System.out.println("Please make a move in the " + getBoardLabelForCoordinates(validQuadrantForNextMove[0], validQuadrantForNextMove[1]) + " board.");
			}
			else {
				// Displays message to the screen that the Player can make their next move on any position on the board
				System.out.println("Please select any available position on the ultimate tic-tac-toe board!" );
			}
		}
		else {
			// Displays message to the screen that the Player can make their next move on any position on the board
			System.out.println("Please select any available position on the ultimate tic-tac-toe board!" );
		}
			// creates variable of integer array type called masterMoveCoordinates and sets it to value of 2
		int[] masterMoveCoordinates = new int[2];
		do {
			masterMoveCoordinates = currentPlayer.GetPlayerInput(); // gets Player input
		}
		// checks for input to be false
		while(validateHumanInput(masterMoveCoordinates, isBlankOnValidQuadrant) == false);
		int row = masterMoveCoordinates[0];
		int column = masterMoveCoordinates[1];
		int[] individualBoardCoordinates = this.getIndividualBoardCoordinates(row, column);
		int modIndividualRow = (row  % 3);
		int modIndividualColumn = (column % 3);
		this.ultimateTTTBoard.getIndividualBoard(individualBoardCoordinates[0], individualBoardCoordinates[1]).setIndividualCell(modIndividualRow, modIndividualColumn, currentPlayer.getPlayerMark());
		if(lastMove.getLastCoordinates() == null) {
			//PreviousMove lastGameMove = new PreviousMove();
			this.lastMove.setLastCoordinates(modIndividualRow, modIndividualColumn);
		}
		else {
			this.lastMove.setLastCoordinates(modIndividualRow, modIndividualColumn);
		}
		return;
		//this.ultimateTTTBoard.getIndividualBoard(row, column).setIndividualCell(row, column, currentPlayer.getPlayerMark());
	}
	// creates public method of boolean type called validateHumanInput
	// to validate the human player's input 
	public boolean validateHumanInput(int[] userInputCoordinates, boolean checkIndividualBoard) {
		// creates variable of boolean type called validInput and sets it to false
		boolean validInput = false;
		// creates variable of integer array type called individualBoardCoordinates and sets it to the individual board coordinates
		int[] individualBoardCoordinates = getIndividualBoardCoordinates(userInputCoordinates[0], userInputCoordinates[1]);
		// creates variable of integer array type called masterBoardCoordinates and sets it to a new instance with size of 2
		int[] masterBoardCoordinates = new int[2];
		// sets masterBoardCoordinates at [0] to getMasterBoardColumn at [0]
		masterBoardCoordinates[0] = ultimateTTTBoard.getMasterBoardColumn(userInputCoordinates[0]);
		// sets masterBoardCoordinates at [1] to getMasterBoardColumn at [1]
		masterBoardCoordinates[1] = ultimateTTTBoard.getMasterBoardColumn(userInputCoordinates[1]);
		// checks individual Board status
		if(!checkIndividualBoard) {
			validInput = (ultimateTTTBoard.getIndividualBoard(masterBoardCoordinates[0], masterBoardCoordinates[1]).getIndividualCell(individualBoardCoordinates[0], individualBoardCoordinates[1]).getCurrentCellValue() == CellConstant.BLANK);
		}
		else {
			// creates variable of integer array type called validQuadrantForNextMove and sets it to last coordinates
			int[] validQuadrantForNextMove = this.lastMove.getLastCoordinates();
			// checks if master board coordinates are in valid quadrants
			if(masterBoardCoordinates[0] == validQuadrantForNextMove[0] && masterBoardCoordinates[1] == validQuadrantForNextMove[1]) {
				validInput = true; // sets validInput value to true
			}
		}
		// checks if validInput is equal to false
		if(validInput == false) {
			System.out.println("Invalid input, please try again!"); // displays error message to the player
		}
		return validInput; // returns validInput variable value
	}
	// creates public method of integer array type called takeAiTurn
	// to control the Ai's turn in the game
	public void takeAiTurn(Player currentPlayer) {
		// checks if lastMove coordinates are not equal to null
		if(this.lastMove.getLastCoordinates() != null) {
			// creates variable of integer array type called nextMoveCoordinates and sets it to null value
			int[] nextMoveCoordinates = null;
			// creates variable of integer array type called validQuadrantForNextMove and sets it the value of the last coordinates
			int[] validQuadrantForNextMove = this.lastMove.getLastCoordinates();
			// creates variable of boolean type called isBlankOnValidQuadrant
			boolean isBlankOnValidQuadrant = ultimateTTTBoard.getIndividualBoard(validQuadrantForNextMove[0], validQuadrantForNextMove[1]).checkBoardForBlank();
			// creates variable of boolean type called isBlankOnMasterBoard
			boolean isBlankOnMasterBoard = ultimateTTTBoard.checkMasterBoardForBlank();
			// checks if value is blank is on the ValidQuadrant
			if(isBlankOnValidQuadrant) {
				nextMoveCoordinates = getValidCoordinatesInQuadrant(validQuadrantForNextMove[0],validQuadrantForNextMove[1]);
				this.ultimateTTTBoard.getIndividualBoard(validQuadrantForNextMove[0], validQuadrantForNextMove[1]).setIndividualCell(nextMoveCoordinates[0], nextMoveCoordinates[1], currentPlayer.getPlayerMark());
				int[] masterBoardCoordinates = getMasterBoardCoordinates(validQuadrantForNextMove[0], validQuadrantForNextMove[1], nextMoveCoordinates[0], nextMoveCoordinates[1]);
				// displays new line and Player O's move
				System.out.println("===========================================================================================================");
				System.out.println("Player O made their move on Row: " + masterBoardCoordinates[0] + " Column: " + masterBoardCoordinates[1]);
			}
			// checks if value is blank is not on the ValidQuadrant and the blank is on the master board
			if((!isBlankOnValidQuadrant) && isBlankOnMasterBoard) {
				int[] nextMoveBoardQuadrant = ultimateTTTBoard.getBoardFromMasterWithBlank();
				nextMoveCoordinates = getValidCoordinatesInQuadrant(nextMoveBoardQuadrant[0],nextMoveBoardQuadrant[1]);
				this.ultimateTTTBoard.getIndividualBoard(nextMoveBoardQuadrant[0], nextMoveBoardQuadrant[1]).setIndividualCell(nextMoveCoordinates[0], nextMoveCoordinates[1], currentPlayer.getPlayerMark());
				int[] masterBoardCoordinates = getMasterBoardCoordinates(nextMoveBoardQuadrant[0], nextMoveBoardQuadrant[1], nextMoveCoordinates[0], nextMoveCoordinates[1]);
				// displays new line and Player O's move
				System.out.println("===========================================================================================================");
				System.out.println("Player O made their move on Row: " + masterBoardCoordinates[0] + " Column: " + masterBoardCoordinates[1]);
			}
			// checks if value is not equal to the isBlankOnValidQuadrant and isBlankOnMasterBoard values
			if(!isBlankOnValidQuadrant && !isBlankOnMasterBoard) {
				this.gameStatus = MasterGameStatus.TIE; // sets the game status at TIE
			}
			System.out.println(); // prints out a new line
			// checks if lastMove coordinates are equal to null and that nextMoveCoordinates is not equal to null value
			if(lastMove.getLastCoordinates() == null && nextMoveCoordinates != null) {
				this.lastMove = new PreviousMove();
				this.lastMove.setLastCoordinates(nextMoveCoordinates[0], nextMoveCoordinates[1]);
			}
			// checks if nextMoveCoordinates is not equal to null value
			else {
				if(nextMoveCoordinates != null) {
					this.lastMove.setLastCoordinates(nextMoveCoordinates[0], nextMoveCoordinates[1]);
				}	
			}
		}
	}
	// creates public method of integer array type called getValidCoordinatesInQuadrant
	// to get the Player's valid coordinates within the coordinate
	public int[] getValidCoordinatesInQuadrant(int masterRow, int masterColumn) {
		// creates variable of integer type called blankLocatedFlag and sets it equal to negative one value
		int blankLocatedFlag = -1;
		// creates variable of integer type called validCoordinates[] and sets it equal to new instance of integer array with size of 2
		int validCoordinates[] = new int[2];
		do {
			// creates variable of Random type called chaos and sets it to new instance of random
			Random chaos = new Random();
			// creates variable of integer type called randomRowInt and sets it to nextInt method with value of 3
			int randomRowInt = chaos.nextInt(3);
			// creates variable of Random type called chaos2 and sets it to new instance of random
			Random chaos2 = new Random();
			// creates variable of integer type called randomColumnInt and sets it to nextInt method with value of 3
			int randomColumnInt = chaos2.nextInt(3);
			// creates variable of GameboardCell type called tempGameboardCell and sets it to individual game board cell values
			GameboardCell tempGameboardCell = ultimateTTTBoard.getIndividualGameBoardCell(masterRow, masterColumn, randomRowInt, randomColumnInt);
			// checks if game board cell is blank
			if (tempGameboardCell.getCurrentCellValue() == CellConstant.BLANK) {
				validCoordinates[0] = randomRowInt;
				validCoordinates[1] = randomColumnInt;
				blankLocatedFlag = 1; // sets blankLocatedFlag variable value to one
			}
		} while (blankLocatedFlag == -1); // checks while blankLocatedFlag is equal to negative one value

		return validCoordinates; // returns validCoordinates variable values
	}
	// creates public method of integer array type called getIndividualBoardCoordinates
	// to get the coordinates of the Player's move in regards to the smaller individual boards
	public int[] getIndividualBoardCoordinates(int masterBoardRow, int masterBoardColumn) {
		// creates variable of integer array type called individualBoardCoordinates and sets it to value of 2
		int[] individualBoardCoordinates = new int[2];
		// creates switch statement to check value of master board row coordinates
		switch(masterBoardRow) {
		case(0): 
			individualBoardCoordinates[0] = 0;
		break;
		case(1):
			individualBoardCoordinates[0] = 0;
		break;
		case(2):
			individualBoardCoordinates[0] = 0;
		break;
		case(3):
			individualBoardCoordinates[0] = 1;
		break;
		case(4):
			individualBoardCoordinates[0] = 1;
		break;
		case(5):
			individualBoardCoordinates[0] = 1;
		break;
		case(6):
			individualBoardCoordinates[0] = 2;
		break;
		case(7):
			individualBoardCoordinates[0] = 2;
		break;
		case(8):
			individualBoardCoordinates[0] = 2;
		break;
		}
		// creates switch statement to set values of master board columns coordinates
		switch(masterBoardColumn) {
		case(0): 
			individualBoardCoordinates[1] = 0;
		break;
		case(1):
			individualBoardCoordinates[1] = 0;
		break;
		case(2):
			individualBoardCoordinates[1] = 0;
		break;
		case(3):
			individualBoardCoordinates[1] = 1;
		break;
		case(4):
			individualBoardCoordinates[1] = 1;
		break;
		case(5):
			individualBoardCoordinates[1] = 1;
		break;
		case(6):
			individualBoardCoordinates[1] = 2;
		break;
		case(7):
			individualBoardCoordinates[1] = 2;
		break;
		case(8):
			individualBoardCoordinates[1] = 2;
		break;
		}
		return individualBoardCoordinates;
	}
	// creates public method of integer array type called getMasterBoardCoordinates
	// to get the coordinates of the Player's move in regards to the master board
	public int[] getMasterBoardCoordinates(int masterBoardRow, int masterBoardColumn, int individualRow, int individualColumn) {
		// creates variable of integer array type called masterBoardCoordinates and sets it to value of 2
		int[] masterBoardCoordinates = new int[2];
		// creates variable of integer type called convertedRow and sets it to value of negative one
		int convertedRow = -1;
		// creates variable of integer type called convertedColumn and sets it to value of negative one
		int convertedColumn = -1;
		// checks if masterBoardRow value is greater than zero
		if(masterBoardRow > 0) {
			convertedRow = (((masterBoardRow) * 3) + (individualRow + 1));
		}
		// checks if masterBoardRow value is equal to zero
		if(masterBoardRow == 0) {
			convertedRow = (individualRow + 1);
		}
		// checks if masterBoardColumn value is greater than zero
		if(masterBoardColumn > 0) {
			convertedColumn = (((masterBoardColumn) * 3) + (individualColumn + 1));
		}
		// checks if masterBoardColumn value is equal to zero
		if(masterBoardColumn == 0) {
			convertedColumn = (individualColumn + 1);
		}
		// sets masterBoardCoordinates for convertedRow and convertedColumn
		masterBoardCoordinates[0] = convertedRow;
		masterBoardCoordinates[1] = convertedColumn;
		return masterBoardCoordinates; // returns masterBoardCoordinates variable value
	}
	// creates public method of void type called printRules
	public void printRules() {
		// displays rules of the tttgame to the screen
		System.out.println("=============================== WELCOME TO THE ULTIMATE TIC-TAC-TOE GAME! ================================");
		System.out.println(" Here are the Rules: ");
		System.out.println("  -  Player X always goes first, and Players will alternate making moves on the various boards.");
		System.out.println("  -  Player X�s first move can be anywhere, but each following moves are determined by your ");
		System.out.println("     opponent�s previous move. Depending on the position of the square they select, ");
		System.out.println("     that�s the board the next move must be played in!");
		System.out.println("        - However, there are TWO exceptions to these rules: ");
		System.out.println("		1. If you are sent to a board that is already won/tied, but not full");
		System.out.println("   			In this case, you are allowed to make a move on that board, " );
		System.out.println("			but the move will not have an effect on the outcome of that board!");
		System.out.println("		2. If you are sent to a board that�s already been full");
		System.out.println("			In this case, you are allowed to go anywhere else on the ");
		System.out.println(" 			ultimate tic-tac-toe board that is still open!");
		System.out.println("  -  The Ultimate Tic-Tac-Toe Game ends when a player has won 3 small boards in a row, column or diagonal!");
		System.out.println("===========================================================================================================");
		}
	// creates public method of PreviousMove type called getLastMove
	// to get the lastMove variable
	public PreviousMove getLastMove() {
		return lastMove; // returns the lastMove variable
	}
	// creates public method of void type called setLastMove
	// to set the lastMove value
	public void setLastMove(PreviousMove lastMove) {
		this.lastMove = lastMove; // sets the lastMove variable
	}
	// creates public method of integer array type called determineValidQuadrant
	// to check the if the quadrant is the appropriate one
	public int[] determineValidQuadrant() {
		if(this.lastMove != null && lastMove.getLastCoordinates() != null) {
			// creates integer array called lastMoveCoordinates and sets it to value of array to 2
			int[] lastMoveCoordinates = new int[2];
			// sets lastMoveCoordinates to the last move coordinates
			lastMoveCoordinates = this.getLastMove().getLastCoordinates();
			// returns the individual board coordinates
			return getIndividualBoardCoordinates(lastMoveCoordinates[0], lastMoveCoordinates[1]);
		}
		return null; // returns a value of null
	}
	// creates public method of boolean type called inputValidator
	// to check the input for validity
	public boolean inputValidator(int[] validQuadrantForNextMove, int[] userInput) {
		// creates variable of integer type called masterBoardRow and calculates the Master Board row
		int masterBoardRow = this.ultimateTTTBoard.calculateMasterBoardRow(userInput[0]);
		// creates variable of integer type called masterBoardColumn and calculates the Master Board column
		int masterBoardColumn = this.ultimateTTTBoard.getMasterBoardColumn(userInput[1]);
		// checks for valid Quadrant
		if(validQuadrantForNextMove[0] == masterBoardRow && validQuadrantForNextMove[1] == masterBoardColumn) {
			return true; // returns value of true
		}
		else 
			return false; // returns value of false
	}
	// creates public method called getValidQuadrantForNextMove
	// to get the value for the validQuadrantForNextMove variable
	public int[] getValidQuadrantForNextMove() {
		return validQuadrantForNextMove; // returns validQuadrantForNextMove variable value
	}
	// creates public method of void type called setValidQuadrantForNextMove
	// sets value for validQuadrantForNextMove value
	public void setValidQuadrantForNextMove(int[] validQuadrantForNextMove) {
		this.validQuadrantForNextMove = validQuadrantForNextMove;
	}
	// creates public method of void type called updateStatusForBoards
	// checks all the positions on the entire board for status of the player marks
	public void updateStatusForBoards() {
		for(int x = 0; x < 3; x++) {
			for(int y = 0; y < 3; y++) {
				ultimateTTTBoard.getIndividualBoard(x, y).checkBoardStatus(this.humanPlayer.getPlayerMark());
				ultimateTTTBoard.getIndividualBoard(x, y).checkBoardStatus(this.aiPlayer.getPlayerMark());
			}
		}
	}
	// creates a public method of String type called getBoardLabelForCoordinates
	// to assign a string name to each quadrant of the board
	public String getBoardLabelForCoordinates(int row, int column) {
		// creates a variable of String type called label and sets it to NULL value
		String label = null;
		// checks if value is in upper-left quadrant
		if(row == 0 && column == 0) {
			label = "upper-left";
		}
		// checks if value is in upper-middle quadrant
		if(row == 0 && column == 1) {
			label = "upper-middle";
		}
		// checks if value is in upper-right quadrant
		if(row == 0 && column == 2) {
			label = "upper-right";
		}
		// checks if value is in middle-left quadrant
		if(row == 1 && column == 0) {
			label = "middle-left";
		}
		// checks if value is in center quadrant
		if(row == 1 && column == 1) {
			label = "center";
		}
		// checks if value is in middle-right quadrant
		if(row == 1 && column == 2) {
			label = "middle-right";
		}
		// checks if value is in lower-left quadrant
		if(row == 2 && column == 0) {
			label = "lower-left";
		}
		// checks if value is in lower-middle quadrant
		if(row == 2 && column == 1) {
			label = "lower-middle";
		}
		// checks if value is in lower-right quadrant
		if(row == 2 && column == 2) {
			label = "lower-right";
		}
		return label; // returns label variable value
	}	
}