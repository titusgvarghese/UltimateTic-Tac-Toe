/*============================================================================
	Name        : MasterGameStatus.Java (enum)
	Author      : Titus Varghese
	Course	    : 2336
	Section     : 006
	Analysis    : This class will store the enum constants used to keep the Master 
				  game status of the Ultimate Tic-Tac-Toe Game.
	Design      : MasterGameStatus is used to store the enums which are to check the
				  board status of the overall ultimate ttt game.
	Test	    : This class was tested in situations to signify a specific master board status.
  ============================================================================*/
// finalProject package
package finalProject;
//creates public method of enumeration type called MasterGameStatus
public enum MasterGameStatus {
	// creates enums called ACTIVE, TIE, XWIN, OWIN
	ACTIVE, TIE, XWIN, OWIN
}