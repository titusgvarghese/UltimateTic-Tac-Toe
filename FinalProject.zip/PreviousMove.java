/*======================================================================================
	Name        : PreviousMove.Java (Class)
	Author      : Titus Varghese
	Course	    : 2336
	Section     : 006
	Analysis    : This class will keep track of the previous move within the 
				  Ultimate Tic-Tac-Toe Game.
	Design      : PreviousMove kept track of the last coordinates the previous player had 
				  made their move on and uses them to move the ultimate ttt game further.
	Test	    : This class was tested using breakpoints, which ensured the proper coordinates 
				  were being passed through at the appropriate times.
  ======================================================================================*/
// finalProject package
package finalProject;
// created a public class called PreviousMove
public class PreviousMove {
	// creates private variable of integer array type called lastCoordinates and set it to new instance of integer array[2]
	private int[] lastCoordinates = new int[2];
	// creates public constructor of PreviousMove
	public PreviousMove() {
		this.lastCoordinates = null; // sets lastCoordinates variable to null value
	}
	// creates public method of void type called setLastCoordinates
	public void setLastCoordinates(int row, int column) {
		int[] pairToSet = new int[2];
		pairToSet[0] = row; // sets pairToSet at value of 0 to row value
		pairToSet[1] = column; // sets pairToSet at value of 0 to column value
		this.lastCoordinates = pairToSet; // sets value of pairToSet to lastCoordinates
	}
	// creates public method of integer array type called getLastCoordinates
	public int[] getLastCoordinates() {
		return lastCoordinates; // returns value of getLastCoordinates variable
	}
	// creates public method of void type called setLastCoordinates
	public void setLastCoordinates(int[] lastCoordinates) {
		this.lastCoordinates = lastCoordinates; // sets value of lastCoordinates to lastCoordinates
	}
}