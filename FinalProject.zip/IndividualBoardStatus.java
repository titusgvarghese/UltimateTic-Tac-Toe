/*======================================================================================
	Name        : IndividualBoardStatus.Java (enum)
	Author      : Titus Varghese
	Course	    : 2336
	Section     : 006
	Analysis    : This class will store the enum constants used to keep the Individual 
				  game status of the smaller games within the Ultimate Tic-Tac-Toe Game.
	Design      : IndividualBoardStatus is used to store the enums which are to check the
				  board status of the individual game boards that make up the ultimate ttt game.
	Test	    : This class was tested in situations to signify a specific board status.
  ======================================================================================*/
// finalProject package
package finalProject;
//creates public method of enumeration type called IndividualBoardStatus
public enum IndividualBoardStatus {
	// creates enums called TIE, XWIN, OWIN, and ACTIVE
	TIE, XWIN, OWIN, ACTIVE
}